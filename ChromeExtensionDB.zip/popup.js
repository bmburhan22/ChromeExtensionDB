$(function(){
    var enabled = false; 
    var myButton = document.getElementById('toggle');
    
    chrome.storage.local.get('enabled', data => {
        enabled = !!data.enabled;
        myButton.textContent = enabled ? 'Disable' : 'Enable';
    });
    
    myButton.onclick = () => {
        enabled = !enabled;
        myButton.textContent = enabled ? 'Disable' : 'Enable';
        chrome.storage.local.set({enabled:enabled});
    };

    chrome.storage.local.get(['datetime'], function(r) {
     $('#lastmessage').text(r.datetime);
    });
    $('#savebutton').click(function(){
        
        var authToken = $("#authtoken").val();
        var postURL = $("#posturl").val();
        var textMessage = $("#textmessage").val();
        var hours = $("#hours").val();
        dict = {'authToken':authToken, 'postURL':postURL, 'textMessage':textMessage, 'hours':hours}
        $.each(dict, function(key, value){
            if (value === "" || value === null){
                delete dict[key];
            }
        });
        chrome.storage.local.set(dict)
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            chrome.tabs.update(tabs[0].id, {url: tabs[0].url});
        });
        
    });

});